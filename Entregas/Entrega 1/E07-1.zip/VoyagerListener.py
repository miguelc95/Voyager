# Generated from Voyager.g4 by ANTLR 4.7.1
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .VoyagerParser import VoyagerParser
else:
    from VoyagerParser import VoyagerParser

# This class defines a complete listener for a parse tree produced by VoyagerParser.
class VoyagerListener(ParseTreeListener):

    # Enter a parse tree produced by VoyagerParser#voyager.
    def enterVoyager(self, ctx:VoyagerParser.VoyagerContext):
        pass

    # Exit a parse tree produced by VoyagerParser#voyager.
    def exitVoyager(self, ctx:VoyagerParser.VoyagerContext):
        pass


    # Enter a parse tree produced by VoyagerParser#line.
    def enterLine(self, ctx:VoyagerParser.LineContext):
        pass

    # Exit a parse tree produced by VoyagerParser#line.
    def exitLine(self, ctx:VoyagerParser.LineContext):
        pass


